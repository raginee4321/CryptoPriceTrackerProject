import { updatePrices, updateCryptocurrency } from '../store/cryptoSlice';
import { store } from '../store';
import { Cryptocurrency } from '../types';

// Generate random price change (between -2% and +2%)
const generateRandomPriceChange = () => {
  return (Math.random() * 4 - 2).toFixed(2);
};

// Generate random volume change (between -5% and +5%)
const generateRandomVolumeChange = () => {
  return (Math.random() * 10 - 5) / 100;
};

// Simulated WebSocket service for real-time crypto updates
export class CryptoWebSocketService {
  private intervalId: number | null = null;
  
  // Start simulated WebSocket connection
  connect() {
    if (this.intervalId) return;
    
    this.intervalId = window.setInterval(() => {
      const cryptocurrencies = store.getState().crypto.cryptocurrencies;
      
      // Generate updates for all cryptocurrencies
      const updates = cryptocurrencies.map(crypto => {
        const priceChangePercent = parseFloat(generateRandomPriceChange());
        const newPrice = crypto.price * (1 + priceChangePercent / 100);
        
        // If it's not USDT (which should stay close to $1)
        const finalPrice = crypto.symbol === 'USDT' 
          ? Math.max(0.99, Math.min(1.01, newPrice))
          : Math.max(0, newPrice);
          
        const volumeChangePercent = generateRandomVolumeChange();
        const newVolume = crypto.volume24h * (1 + volumeChangePercent);
        
        // Update 1h price change
        const newPriceChange1h = Math.max(-15, Math.min(15, 
          crypto.priceChange1h + (Math.random() * 0.4 - 0.2)
        ));
        
        // Update 24h price change
        const newPriceChange24h = Math.max(-25, Math.min(25, 
          crypto.priceChange24h + (Math.random() * 0.6 - 0.3)
        ));
        
        return {
          id: crypto.id,
          price: parseFloat(finalPrice.toFixed(2)),
          priceChange1h: parseFloat(newPriceChange1h.toFixed(2)),
          priceChange24h: parseFloat(newPriceChange24h.toFixed(2)),
          volume24h: Math.round(newVolume),
        };
      });
      
      // Dispatch updates to Redux
      store.dispatch(updatePrices(updates));
      
    }, 1500); // Update every 1.5 seconds
  }
  
  // Stop simulated WebSocket connection
  disconnect() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }
  
  // Simulate updating a specific cryptocurrency
  updateCrypto(id: number, updates: Partial<Cryptocurrency>) {
    store.dispatch(updateCryptocurrency({ id, ...updates }));
  }
}

// Create singleton instance
export const cryptoService = new CryptoWebSocketService();