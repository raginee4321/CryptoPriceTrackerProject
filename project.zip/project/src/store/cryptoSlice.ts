import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { CryptoState, Cryptocurrency } from '../types';
import { initialCryptoData } from '../data/initialData';

const initialState: CryptoState = {
  cryptocurrencies: initialCryptoData,
  loading: false,
  error: null,
  lastUpdated: new Date().toISOString(),
};

export const cryptoSlice = createSlice({
  name: 'crypto',
  initialState,
  reducers: {
    updatePrices: (state, action: PayloadAction<{ id: number; price: number; priceChange1h: number; priceChange24h: number; volume24h: number }[]>) => {
      action.payload.forEach((update) => {
        const crypto = state.cryptocurrencies.find((c) => c.id === update.id);
        if (crypto) {
          crypto.price = update.price;
          crypto.priceChange1h = update.priceChange1h;
          crypto.priceChange24h = update.priceChange24h;
          crypto.volume24h = update.volume24h;
        }
      });
      state.lastUpdated = new Date().toISOString();
    },
    
    updateCryptocurrency: (state, action: PayloadAction<Partial<Cryptocurrency> & { id: number }>) => {
      const { id, ...updates } = action.payload;
      const index = state.cryptocurrencies.findIndex(crypto => crypto.id === id);
      
      if (index !== -1) {
        state.cryptocurrencies[index] = {
          ...state.cryptocurrencies[index],
          ...updates
        };
      }
      
      state.lastUpdated = new Date().toISOString();
    },
    
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    
    setError: (state, action: PayloadAction<string | null>) => {
      state.error = action.payload;
    }
  },
});

export const { updatePrices, updateCryptocurrency, setLoading, setError } = cryptoSlice.actions;

export default cryptoSlice.reducer;