export interface Cryptocurrency {
  id: number;
  name: string;
  symbol: string;
  logo: string;
  price: number;
  priceChange1h: number;
  priceChange24h: number;
  priceChange7d: number;
  marketCap: number;
  volume24h: number;
  circulatingSupply: number;
  maxSupply: number | null;
  chartData: number[];
}

export interface CryptoState {
  cryptocurrencies: Cryptocurrency[];
  loading: boolean;
  error: string | null;
  lastUpdated: string;
}