import React from 'react';
import { useAppSelector } from '../hooks/useAppSelector';
import CryptoTableRow from './CryptoTableRow';
import { ArrowDownUp } from 'lucide-react';

const CryptoTable: React.FC = () => {
  const { cryptocurrencies, lastUpdated } = useAppSelector((state) => state.crypto);
  
  return (
    <div className="w-full overflow-x-auto rounded-lg shadow-lg">
      <div className="bg-gray-800 text-gray-300 p-4 flex justify-between items-center">
        <h2 className="text-lg font-semibold">Cryptocurrency Market</h2>
        <div className="text-xs">
          Last updated: {new Date(lastUpdated).toLocaleTimeString()}
        </div>
      </div>
      
      <table className="w-full text-sm text-left">
        <thead className="text-xs text-gray-400 uppercase bg-gray-900">
          <tr>
            <th className="px-4 py-3">#</th>
            <th className="px-4 py-3">Name</th>
            <th className="px-4 py-3">Price</th>
            <th className="px-4 py-3">
              <div className="flex items-center gap-1">
                1h % <ArrowDownUp size={12} />
              </div>
            </th>
            <th className="px-4 py-3">
              <div className="flex items-center gap-1">
                24h % <ArrowDownUp size={12} />
              </div>
            </th>
            <th className="px-4 py-3">
              <div className="flex items-center gap-1">
                7d % <ArrowDownUp size={12} />
              </div>
            </th>
            <th className="px-4 py-3">Market Cap</th>
            <th className="px-4 py-3">24h Volume</th>
            <th className="px-4 py-3">Circulating Supply</th>
            <th className="px-4 py-3">7d Chart</th>
          </tr>
        </thead>
        <tbody>
          {cryptocurrencies.map((crypto, index) => (
            <CryptoTableRow key={crypto.id} crypto={crypto} index={index} />
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CryptoTable;