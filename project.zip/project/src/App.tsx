import React, { useEffect } from 'react';
import { Provider } from 'react-redux';
import { store } from './store';
import { cryptoService } from './services/cryptoService';
import CryptoTable from './components/CryptoTable';
import Header from './components/Header';
import Footer from './components/Footer';
import PriceStatisticCard from './components/PriceStatisticCard';

const CryptoTrackerApp: React.FC = () => {
  // Start the simulated WebSocket connection when the component mounts
  useEffect(() => {
    cryptoService.connect();
    
    // Cleanup: disconnect when component unmounts
    return () => {
      cryptoService.disconnect();
    };
  }, []);
  
  return (
    <div className="flex flex-col min-h-screen bg-gray-900 text-white">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold mb-2">Cryptocurrency Market</h1>
          <p className="text-gray-400">
            Real-time prices and market data for the top cryptocurrencies, updated every few seconds.
          </p>
        </div>
        
        <PriceStatisticCard />
        <CryptoTable />
      </main>
      
      <Footer />
    </div>
  );
};

function App() {
  return (
    <Provider store={store}>
      <CryptoTrackerApp />
    </Provider>
  );
}

export default App;