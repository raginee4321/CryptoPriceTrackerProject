import React, { useMemo } from 'react';
import { Cryptocurrency } from '../types';
import PriceChangeCell from './PriceChangeCell';
import MiniChart from './MiniChart';

interface CryptoTableRowProps {
  crypto: Cryptocurrency;
  index: number;
}

const CryptoTableRow: React.FC<CryptoTableRowProps> = ({ crypto, index }) => {
  // Memoize formatted values to prevent unnecessary re-renders
  const formattedValues = useMemo(() => ({
    price: new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: crypto.symbol === 'USDT' ? 3 : 2,
      maximumFractionDigits: crypto.symbol === 'USDT' ? 3 : 2,
    }).format(crypto.price),
    
    marketCap: new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      notation: 'compact',
      compactDisplay: 'short',
      maximumFractionDigits: 2,
    }).format(crypto.marketCap),
    
    volume24h: new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      notation: 'compact',
      compactDisplay: 'short',
      maximumFractionDigits: 2,
    }).format(crypto.volume24h),
    
    circulatingSupply: new Intl.NumberFormat('en-US', {
      notation: 'compact',
      compactDisplay: 'short',
      maximumFractionDigits: 2,
    }).format(crypto.circulatingSupply),
    
    maxSupply: crypto.maxSupply
      ? new Intl.NumberFormat('en-US', {
          notation: 'compact',
          compactDisplay: 'short',
          maximumFractionDigits: 2,
        }).format(crypto.maxSupply)
      : '∞',
  }), [crypto]);
  
  const bgColor = index % 2 === 0 ? 'bg-gray-800' : 'bg-gray-900';
  
  return (
    <tr className={`${bgColor} border-b border-gray-700 hover:bg-gray-700 transition-colors`}>
      <td className="px-4 py-3 font-semibold text-gray-400">{index + 1}</td>
      <td className="px-4 py-3">
        <div className="flex items-center gap-2">
          <img 
            src={crypto.logo} 
            alt={crypto.name} 
            className="w-6 h-6 rounded-full" 
          />
          <div>
            <div className="font-medium text-white">{crypto.name}</div>
            <div className="text-xs text-gray-400">{crypto.symbol}</div>
          </div>
        </div>
      </td>
      <td className="px-4 py-3 font-medium text-white">
        {formattedValues.price}
      </td>
      <PriceChangeCell value={crypto.priceChange1h} />
      <PriceChangeCell value={crypto.priceChange24h} />
      <PriceChangeCell value={crypto.priceChange7d} />
      <td className="px-4 py-3 text-gray-300">{formattedValues.marketCap}</td>
      <td className="px-4 py-3 text-gray-300">{formattedValues.volume24h}</td>
      <td className="px-4 py-3 text-gray-300">
        <div className="flex flex-col">
          <span>{formattedValues.circulatingSupply} {crypto.symbol}</span>
          {crypto.maxSupply && (
            <span className="text-xs text-gray-400">
              Max: {formattedValues.maxSupply} {crypto.symbol}
            </span>
          )}
        </div>
      </td>
      <td className="px-4 py-3">
        <MiniChart 
          data={crypto.chartData} 
          isPositive={crypto.priceChange7d >= 0} 
        />
      </td>
    </tr>
  );
};

export default CryptoTableRow;