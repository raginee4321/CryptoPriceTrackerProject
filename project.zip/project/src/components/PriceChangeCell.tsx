import React from 'react';
import { ArrowUp, ArrowDown } from 'lucide-react';

interface PriceChangeCellProps {
  value: number;
}

const PriceChangeCell: React.FC<PriceChangeCellProps> = ({ value }) => {
  const isPositive = value >= 0;
  const color = isPositive ? 'text-green-500' : 'text-red-500';
  const bgColor = isPositive ? 'bg-green-500/10' : 'bg-red-500/10';
  const Icon = isPositive ? ArrowUp : ArrowDown;
  
  return (
    <td className="px-4 py-3">
      <div className={`inline-flex items-center gap-1 rounded px-2 py-1 ${color} ${bgColor}`}>
        <Icon size={12} />
        <span className="font-medium">{Math.abs(value).toFixed(2)}%</span>
      </div>
    </td>
  );
};

export default PriceChangeCell;