import React from 'react';
import { useAppSelector } from '../hooks/useAppSelector';
import { ArrowUpRight, ArrowDownRight, DollarSign, BarChart4, Activity } from 'lucide-react';

const PriceStatisticCard: React.FC = () => {
  const { cryptocurrencies } = useAppSelector((state) => state.crypto);
  
  // Calculate statistics
  const totalMarketCap = cryptocurrencies.reduce((sum, crypto) => sum + crypto.marketCap, 0);
  const total24hVolume = cryptocurrencies.reduce((sum, crypto) => sum + crypto.volume24h, 0);
  
  // Calculate average 24h change
  const avg24hChange = cryptocurrencies.reduce((sum, crypto) => sum + crypto.priceChange24h, 0) / cryptocurrencies.length;
  
  const stats = [
    {
      title: 'Total Market Cap',
      value: new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        notation: 'compact',
        compactDisplay: 'short',
      }).format(totalMarketCap),
      icon: <DollarSign className="text-blue-500" />,
    },
    {
      title: '24h Trading Volume',
      value: new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        notation: 'compact',
        compactDisplay: 'short',
      }).format(total24hVolume),
      icon: <BarChart4 className="text-purple-500" />,
    },
    {
      title: 'Average 24h Change',
      value: `${avg24hChange.toFixed(2)}%`,
      isPositive: avg24hChange >= 0,
      icon: <Activity className="text-green-500" />,
    },
  ];
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      {stats.map((stat, index) => (
        <div key={index} className="bg-gray-800 rounded-lg p-4 shadow-lg">
          <div className="flex items-center justify-between">
            <div className="p-2 rounded-lg bg-gray-700/50">
              {stat.icon}
            </div>
            
            {'isPositive' in stat && (
              <div className={`flex items-center ${stat.isPositive ? 'text-green-500' : 'text-red-500'}`}>
                {stat.isPositive ? (
                  <ArrowUpRight size={18} />
                ) : (
                  <ArrowDownRight size={18} />
                )}
              </div>
            )}
          </div>
          
          <h3 className="text-gray-400 text-sm mt-3">{stat.title}</h3>
          <p className="text-white text-xl font-semibold mt-1">{stat.value}</p>
        </div>
      ))}
    </div>
  );
};

export default PriceStatisticCard;