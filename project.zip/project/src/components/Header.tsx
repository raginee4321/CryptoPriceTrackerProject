import React from 'react';
import { Activity } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gray-900 border-b border-gray-800">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Activity className="text-blue-500" size={28} />
          <h1 className="text-xl font-bold text-white">CryptoTracker</h1>
        </div>
        <nav>
          <ul className="flex gap-4 text-sm">
            <li><a href="#" className="text-white hover:text-blue-400 transition-colors">Dashboard</a></li>
            <li><a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">Markets</a></li>
            <li><a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">Portfolio</a></li>
            <li><a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">About</a></li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;